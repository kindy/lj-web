
local config = {version = '__version__'}

return config

